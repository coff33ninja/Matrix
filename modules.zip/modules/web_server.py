#!/usr/bin/env python3
"""
Web server module for LED Matrix Control Center
Serves the web interface and handles static files
"""

import os
import sys
import http.server
import socketserver
from pathlib import Path

class MatrixWebServer:
    def __init__(self, port=3000):
        self.port = port
        self.sites_dir = Path(__file__).parent.parent / "sites"
    
    def start(self):
        """Start the web server"""
        if not self.sites_dir.exists():
            print(f"❌ Sites directory not found: {self.sites_dir}")
            return False
        
        # Change to sites directory
        original_cwd = os.getcwd()
        os.chdir(self.sites_dir)
        
        try:
            # Custom handler to serve files with correct MIME types
            class CustomHandler(http.server.SimpleHTTPRequestHandler):
                def end_headers(self):
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
                    self.send_header('Access-Control-Allow-Headers', 'Content-Type')
                    super().end_headers()
                
                def do_OPTIONS(self):
                    self.send_response(200)
                    self.end_headers()
            
            with socketserver.TCPServer(("", self.port), CustomHandler) as httpd:
                print("=" * 60)
                print("🌐 LED Matrix Control Center - Web Server")
                print("=" * 60)
                print(f"📅 Started: {__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                print(f"🌍 Server: http://localhost:{self.port}")
                print(f"📁 Serving: {self.sites_dir}")
                print("=" * 60)
                print("💡 Make sure the Python controller is running on port 8080")
                print("   Command: python matrix.py controller")
                print("=" * 60)
                print("Press Ctrl+C to stop the server")
                print()
                
                httpd.serve_forever()
                
        except KeyboardInterrupt:
            print("\n🛑 Server stopped by user")
            return True
        except Exception as e:
            print(f"❌ Server error: {e}")
            return False
        finally:
            os.chdir(original_cwd)

def main():
    """Main entry point for standalone web server"""
    server = MatrixWebServer()
    server.start()

if __name__ == "__main__":
    main()