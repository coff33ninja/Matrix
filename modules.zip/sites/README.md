# LED Matrix Control Center - Web Interface

A modern, responsive web interface for controlling your LED matrix project. This interface connects directly to your Python modules and provides real-time control capabilities.

## 🚀 Quick Start

### Option 1: Start Everything at Once
```bash
python matrix.py start
```
This starts both the GUI controller and web interface server.

### Option 2: Start Services Separately

#### Start the Python Controller
```bash
python matrix.py controller
```
This starts both the GUI and the web API server on port 8080.

#### Start the Web Interface
```bash
python matrix.py web
```
This serves the web interface on port 3000.

### 3. Access the Interface
Open your browser and go to: `http://localhost:3000`

## 🎮 Features

### Control Panel
- **Real-time pattern control** with live preview
- **Color picker** with brightness and speed controls
- **Pattern types**: Solid, Rainbow, Plasma, Fire, Matrix Rain
- **Matrix preview** showing current display state
- **Activity log** with timestamped events

### Arduino Code Generator
- **Multi-board support**: Uno, Nano, ESP32, ESP8266, Mega
- **Automatic code generation** based on matrix size
- **Board comparison** showing memory usage and suitability
- **One-click download** of generated Arduino code

### Wiring Diagram Generator
- **Interactive wiring guides** for different controllers
- **Power requirement calculations** with PSU recommendations
- **Component lists** with estimated costs
- **Downloadable guides** in Markdown format

### Configuration Management
- **Connection settings** (USB/WiFi, ports, baud rates)
- **Backup and restore** functionality
- **Real-time configuration updates**

### System Monitoring
- **Live system stats** (CPU, memory, uptime)
- **Hardware information** display
- **Performance metrics** tracking

## 🔧 API Endpoints

The web interface communicates with the Python controller via these endpoints:

### Status & Control
- `GET /status` - Get controller status and matrix info
- `POST /pattern` - Apply patterns with parameters
- `POST /clear` - Clear the matrix display

### Code Generation
- `POST /generate` - Generate Arduino code
- `POST /wiring` - Generate wiring diagrams

### Configuration
- `GET /config` - Get current configuration
- `POST /config` - Save configuration changes
- `POST /backup` - Create configuration backup
- `GET /backups` - List available backups

### System Info
- `GET /system` - Get system statistics
- `GET /hardware` - Get hardware information

## 🎨 Interface Sections

### 1. Control
- Pattern selection and customization
- Real-time matrix preview
- Color and brightness controls
- Activity logging

### 2. Generator
- Arduino code generation
- Board comparison and recommendations
- Matrix size configuration

### 3. Wiring
- Wiring diagram generation
- Power requirement calculations
- Component specifications

### 4. Config
- Connection settings
- Backup management
- Configuration persistence

### 5. Monitor
- System performance metrics
- Hardware status information
- Real-time monitoring

## 🔗 Integration with Python Modules

The web interface directly integrates with your existing Python modules:

- **`matrix_controller.py`** - Main controller and web API
- **`arduino_generator.py`** - Code generation functionality
- **`wiring_diagram_generator.py`** - Wiring guide creation
- **`matrix_config.py`** - Configuration management
- **`matrix_hardware.py`** - Hardware communication

## 🎯 Benefits Over Original HTML

### ✅ Improvements
- **Direct integration** with Python modules (no static content)
- **Real-time updates** and live preview
- **Modern, responsive design** that works on all devices
- **Functional API endpoints** that actually work
- **No external CDN dependencies** (production-ready)
- **Proper error handling** and user feedback
- **Organized sections** with clear navigation

### 🔧 Technical Improvements
- **CORS properly configured** for cross-origin requests
- **JSON API responses** instead of static content
- **Real-time status updates** every 2 seconds
- **Proper error handling** with user-friendly messages
- **Local asset serving** (no external dependencies)
- **Mobile-responsive design** for all screen sizes

## 🚀 Usage Examples

### Apply a Rainbow Pattern
```javascript
// Via web interface - just select "Rainbow" and click "Apply Pattern"
// Via API:
fetch('http://localhost:8080/pattern', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        pattern: 'rainbow',
        brightness: 200,
        speed: 75
    })
});
```

### Generate Arduino Code
```javascript
// Via web interface - configure board and matrix size, click "Generate"
// Via API:
fetch('http://localhost:8080/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        board: 'esp32',
        width: 16,
        height: 16
    })
});
```

## 🛠️ Development

### File Structure
```
sites/
├── index.html          # Main web interface
├── app.js             # JavaScript application logic
├── README.md          # This documentation
└── (served by serve_web.py)
```

### Customization
- **Colors**: Modify CSS variables in `index.html`
- **Features**: Add new sections and API endpoints
- **Patterns**: Extend pattern types in both JS and Python
- **Styling**: Update CSS for different themes

## 🔍 Troubleshooting

### Common Issues

1. **"Failed to connect to matrix controller"**
   - Ensure `python matrix.py controller` is running
   - Check that port 8080 is not blocked

2. **"CORS errors in browser console"**
   - Make sure you're accessing via `http://localhost:3000`
   - Don't open the HTML file directly in browser

3. **"Web interface not loading"**
   - Run `python serve_web.py` to start the web server
   - Check that port 3000 is available

4. **"API endpoints not working"**
   - Verify the Python controller is running with web server
   - Check browser developer tools for error messages

### Debug Mode
Enable debug logging by modifying the JavaScript console:
```javascript
window.matrixController.log('Debug message', 'info');
```

## 🎉 Next Steps

1. **Start both servers** (Python controller + web server)
2. **Open the web interface** in your browser
3. **Test the connection** using the status indicator
4. **Try different patterns** and see them in the preview
5. **Generate Arduino code** for your specific setup
6. **Create wiring diagrams** for your hardware configuration

The new web interface provides a much more integrated and functional experience compared to the original static HTML file, with real-time updates and direct integration with your Python modules.